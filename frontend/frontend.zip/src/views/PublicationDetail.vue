


watch(() => publicationStore.error, (newError) => {
  if (newError) {
    error(newError, 'Veröffentlichung konnte nicht geladen werden')
  }
})

const formatDate = (dateString) => {
  const date = new Date(dateString)
  return date.toLocaleDateString('de-DE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  })
}

const getAvatarUrl = (author) => {
  if (!author) return 'https://api.dicebear.com/7.x/avataaars/svg?seed=anonymous'
  const seed = `${author.firstName}-${author.lastName}``.toLowerCase()
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(seed)}`
}

const getAuthorName = (author) => {
  if (!author) return 'Anonym'
  return `${author.firstName} ${author.lastName}`
}

const handleLike = async (id) => {
  reacting.value = true
  const result = await publicationStore.likePublication(id)
  reacting.value = false

  if (!result.success) {
    error(result.error || 'Bewertung fehlgeschlagen', 'Bewertung fehlgeschlagen')
  }
}

const handleDislike = async (id) => {
  reacting.value = true
  const result = await publicationStore.dislikePublication(id)
  reacting.value = false

  if (!result.success) {
    error(result.error || 'Bewertung fehlgeschlagen', 'Bewertung fehlgeschlagen')
  }
}
</script>

<style scoped>
/* Add your styles here */
</style>
